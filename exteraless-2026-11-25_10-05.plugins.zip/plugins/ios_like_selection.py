__id__ = "ios_like_selection"
__name__ = "IOS-like selection"
__description__ = "Recreates the effect of selecting a message by tapping like on **IOS**"
__author__ = "@PESSDES_Plugins"
__min_version__ = "12.0.0" 
__icon__ = "VoiceToText7/6"
__version__ = "7.4"

import time
from typing import Any, Callable, Tuple

from android.animation import (Animator, AnimatorSet, ObjectAnimator,
                               ValueAnimator)
from android.graphics import Canvas, Color, PorterDuff
from android.graphics.drawable import BitmapDrawable
from android.os import Build
from android.view import Gravity, MotionEvent, View, ViewGroup
from android.view.animation import (AccelerateInterpolator,
                                    DecelerateInterpolator)
from android.widget import FrameLayout, LinearLayout, PopupWindow, ScrollView
from android_utils import OnClickListener, run_on_ui_thread
from base_plugin import BasePlugin, MethodHook
from client_utils import get_last_fragment, get_media_controller
from com.exteragram.messenger.components import ActionRow
from hook_utils import get_private_field
from java import dynamic_proxy
from java import jfloat as JFloat
from java import jint as JInt
from java.lang import Boolean, Float, Integer, Runnable
from ui.settings import Divider, Header, Selector, Switch

from org.telegram.messenger import (AndroidUtilities, MessageObject,
                                    SharedConfig)
from org.telegram.ui import ChannelAdminLogActivity, ChatActivity
from org.telegram.ui.ActionBar import ActionBarPopupWindow
from org.telegram.ui.Cells import ChatActionCell, ChatMessageCell
from org.telegram.ui.Components import LayoutHelper, ReactionsContainerLayout

jboolean = Boolean.TYPE
jfloat = Float.TYPE
jint = Integer.TYPE

MATCH_PARENT = ViewGroup.LayoutParams.MATCH_PARENT
WRAP_CONTENT = ViewGroup.LayoutParams.WRAP_CONTENT

SHADER_BLUR_SUPPORTED = Build.VERSION.SDK_INT >= 31
if SHADER_BLUR_SUPPORTED:
    from android.graphics import RenderEffect, Shader

def log(*msg):
    from android_utils import log as logcat
    if len(msg) == 0:
        return
    m = msg if len(msg) > 1 else msg[0]
    if isinstance(m, Exception) and m.__traceback__ is not None:
        m = f"{m.__traceback__.tb_lineno}: {m}"
    logcat(f'[{__id__}] {m}')

def ctx():
    return get_last_fragment().getContext()

def content(chat_activity: ChatActivity | ChannelAdminLogActivity):
    return chat_activity.getContentView() if isinstance(chat_activity, ChatActivity) else get_private_field(chat_activity, "contentView");

_cpm_cache = {}
def call_private_method(obj, name, *args):
    method = _cpm_cache.get((name, len(args)), None)
    if not method:
        for m in obj.getClass().getDeclaredMethods():
            if m.getName() == name and len(m.getParameterTypes()) == len(args):
                method = m
                break
        if method is None:
            raise Exception(f'Method {name} not found in {obj.getClass()}')
        method.setAccessible(True)
        _cpm_cache[(name, len(args))] = method
    return method.invoke(obj, *args)

def get_display_metrics():
    try:
        display_metrics = ctx().getResources().getDisplayMetrics()
    except Exception as e:
        display_metrics = None
        log(e)
        
    if not display_metrics:
        display_metrics = AndroidUtilities.displayMetrics
        
    if not display_metrics:
        display_metrics = AndroidUtilities.displaySize
        return display_metrics.x, display_metrics.y 

    return display_metrics.widthPixels, display_metrics.heightPixels

display_width, display_height = get_display_metrics()

class Plugin(BasePlugin):
    instance: "Plugin | None" = None
    
    def on_plugin_load(self) -> None:
        self.dismiss_hook = None
        self.draw_hook = None
        self.swipeback_scroll_hook = None
        Plugin.instance = self
        
        self.hook_method(
            [x for x in ChatActivity.getClass().getDeclaredMethods() if x.getName() == "createMenu"][-1], 
            CreateMenuHook()
        )
        
        self.hook_method(
            [x for x in ChannelAdminLogActivity.getClass().getDeclaredMethods() if x.getName() == "createMenu"][-1],
            CreateMenuHook()
        )
        
        self.hook_method(
            ActionBarPopupWindow.getClass().getDeclaredMethod("showAtLocation", View, jint, jint, jint),
            ShowPopupHook()
        )
        
        self.hook_method(
            ChatMessageCell.getClass().getDeclaredMethod("onTouchEvent", MotionEvent),
            PreventTouch()
        )
        
        self.hook_method(
            ChatActionCell.getClass().getDeclaredMethod("onTouchEvent", MotionEvent),
            PreventTouch()
        )
    
    blurs = [
        25,
        50,
        100,
        150,
        250,
        350
    ]
    
    animation_speeds = [
        0.25,
        0.5,
        0.75,
        1,
        1.5,
        2,
        2.5,
        3
    ]
    
    def create_settings(self) -> list[Any]:
        try:
            settings = []
            
            settings.append(Header("Blur"))
            settings.append(Selector('radius', 'Blur Radius', items=[str(x) for x in self.blurs], icon='msg_blur_radial', default=4, link_alias="blur_radius"))
            if SHADER_BLUR_SUPPORTED:
                settings.append(Switch("force_simple", "Simple mode", True, subtext="Use more optimized blur method", link_alias="simple_mode"))
                if not self.use_alt_blur():
                    settings.append(Divider('A larger blur radius may cause lags'))
            
            settings.append(Header("Animations"))
            settings.append(Selector('animations_speed', 'Animations speed', default=3, items=[f'x{x}' for x in self.animation_speeds], icon="msg_premium_speed", link_alias="animations_speed"))
            
            settings.append(Header("Others"))
            settings.append(Switch("scroll_from_bottom", "Scroll from bottom", True, link_alias="bottom_scroll"))
            settings.append(Switch("sticky_reactions_bar", '"Sticky" reactions bar', True, subtext="Moves the reaction panel over the message like IOS", link_alias="sticky_reactions_bar"))
            
            return settings
        except Exception as e:
            log(e)
    
    @classmethod
    def get_radius(cls):
        try:
            if not cls.instance:
                return cls.blurs[4]
            return cls.blurs[int(cls.instance.get_setting('radius', 4))]
        except Exception as e:
            log(e)
    
    @classmethod
    def enable_animations(cls):
        return True
    
    @classmethod
    def get_animation_speed(cls):
        if not cls.instance:
            return cls.animation_speeds[3]
        return 0 if not cls.enable_animations() else cls.animation_speeds[int(cls.instance.get_setting("animations_speed", 3))]
    
    @classmethod
    def scroll_from_bottom(cls):
        if not cls.instance:
            return True
        return cls.instance.get_setting("scroll_from_bottom", True)
    
    @classmethod
    def use_alt_blur(cls):
        if not cls.instance:
            return not SHADER_BLUR_SUPPORTED
        return not SHADER_BLUR_SUPPORTED or cls.instance.get_setting("force_simple", True)

    @classmethod
    def sticky_reactions_bar(cls):
        if not cls.instance:
            return True
        return cls.instance.get_setting("sticky_reactions_bar", True)

class Stopwatch:
    def __init__(self):
        self.reset()
    
    def reset(self):
        self._start = 0
        self._stop = 0
    
    def start(self):
        self._start = time.time()
    
    def stop(self):
        self._stop = time.time()
    
    def ensure(self):
        if self._stop < self._start:
            self._stop = time.time()
        return self._stop - self._start
    
    def ensure_int(self):
        return int(self.ensure())
    
    def pop(self):
        result = self.ensure()
        self.reset()
        return result
    
    def pop_int(self):
        return int(self.pop())

current_chat_activity: ChatActivity | ChannelAdminLogActivity | None = None
current_message_cell: ChatMessageCell | ChatActionCell | None = None
touch_stopwatch = Stopwatch()

def apply_blur(view, radius):
    if SHADER_BLUR_SUPPORTED:
        if radius <= 0:
            view.setRenderEffect(None)
        else:
            view.setRenderEffect(RenderEffect.createBlurEffect(radius, radius, Shader.TileMode.MIRROR))

class PreventTouch(MethodHook):
    def before_hooked_method(self, param):
        if param.thisObject.getTag() == __id__:
            param.setResult(False)

class ShowPopupHook(MethodHook):  
    def __init__(self) -> None:
        self.out_animation: AnimatorSet | None = None
        self.cell_stopwatch = Stopwatch()
        
    def before_hooked_method(self, param):
        try:
            if not current_chat_activity or touch_stopwatch.ensure() > 0.4:
                return
            
            self.original_y = param.args[3]
            self.original_x = param.args[2]
            param.args[2] = JInt(0)
            param.args[3] = JInt(0) 
            
            self._before_hooked_method(param.thisObject, *param.args)
        except Exception as e:
            log(e)
    
    def _pop_globals(self) -> Tuple[ChatActivity | None, ChatMessageCell | ChatActionCell | None]:
        global current_chat_activity, current_message_cell
        ca, mc = current_chat_activity, current_message_cell
        current_chat_activity = None
        current_message_cell = None
        return ca, mc
    
    def _before_hooked_method(self, this: ActionBarPopupWindow, *_):   
        try: 
            log("Preparing menu...")
            if self.out_animation is not None and self.out_animation.isRunning():
                self.out_animation.cancel()
                self.out_animation = None
                
            current_chat_activity, current_message_cell = self._pop_globals()
            is_message = isinstance(current_message_cell, ChatMessageCell)
            if current_message_cell is None or (
                    (is_message and current_message_cell.getCurrentMessagesGroup() is not None) or 
                    (current_message_cell.getMessageObject().isRoundVideo() and get_media_controller().isPlayingMessage(current_message_cell.getMessageObject()))):
                cell = None
            else:
                cell = self._copy_message_cell(current_message_cell)

            this.setWidth(MATCH_PARENT)
            this.setHeight(MATCH_PARENT)
            this.setClippingEnabled(False) 
            
            old_content = this.getContentView()
            old_content.applyViewBottom(None)
            children = []
            for i in range(old_content.getChildCount()):
                children.append(old_content.getChildAt(i))

            old_content.removeAllViews()

            new_content = FrameLayout(ctx())
            new_content.setLayoutParams(FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            new_content.setClickable(True) 
            new_content.setClipChildren(False)

            scroll_view = ScrollView(ctx())
            scroll_view.setLayoutParams(FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            scroll_view.setFillViewport(True)
            scroll_view.setClipChildren(False)
            scroll_view.setClipToPadding(False)
            scroll_view.setOverScrollMode(View.OVER_SCROLL_NEVER) 
            scroll_view.setVerticalScrollBarEnabled(False)

            inner_container = LinearLayout(ctx())
            inner_container.setOrientation(LinearLayout.VERTICAL)
            inner_container.setLayoutParams(FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            
            w_spec = View.MeasureSpec.makeMeasureSpec(display_width, View.MeasureSpec.AT_MOST)
            h_spec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)

            if current_message_cell is not None:
                is_out = current_message_cell.getMessageObject().isOutOwner()
                is_channel = current_message_cell.getMessageObject().isFromChannel()
            else:
                is_out = None
                is_channel = None
            
            if cell:
                gravity = Gravity.CENTER if not is_message else Gravity.RIGHT if is_out and not is_channel else Gravity.LEFT
                lp = LayoutHelper.createLinear(WRAP_CONTENT, WRAP_CONTENT, gravity)
            else:
                gravity = None
                lp = None
            
            if cell:
                cell.setLayoutParams(LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
                inner_container.addView(cell)
                cell.setLongClickable(False)
                cell.setClickable(False)
                cell.setOnClickListener(OnClickListener(lambda *_: None))
            
            dismiss = OnClickListener(lambda *_: this.dismiss())
            inner_container.setOnClickListener(dismiss)
            new_content.setOnClickListener(dismiss)
            scroll_view.setOnClickListener(dismiss)
            
            message_height = current_message_cell.getHeight() if cell else 0

            reactions_height = 0
            reactions_view: ReactionsContainerLayout | None = None
            if len(children) > 0 and isinstance(children[0], ReactionsContainerLayout):
                reactions_view = children.pop(0)
                if lp:
                    reactions_view.setLayoutParams(lp)
                else:
                    reactions_view.setLayoutParams(LayoutHelper.createLinear(WRAP_CONTENT, WRAP_CONTENT, Gravity.LEFT))
                
                reactions_view.measure(w_spec, h_spec)
                reactions_height = reactions_view.getMeasuredHeight()

            bottom_menu_views: list[tuple[View, int, str | None]] = []
            popup_actions_menu = None
            popup_actions_grouped_menu = None

            for child in children:
                if isinstance(child, FrameLayout) and child.getChildCount() > 0 and isinstance(child.getChildAt(0), ActionRow):
                    popup_actions_grouped_menu = child
                
                if lp:
                    child_lp = LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT)
                    child_lp.gravity = gravity
                    child.setLayoutParams(child_lp)
                
                inner_container.addView(child)
                child.measure(w_spec, h_spec)
                
                if not popup_actions_menu and isinstance(child, ActionBarPopupWindow.ActionBarPopupWindowLayout):
                    popup_actions_menu = child
                    popup_actions_menu.swipeBackGravityRight = gravity == Gravity.RIGHT
                    
                    swipe_back = popup_actions_menu.getSwipeBack()
                    if swipe_back:
                        if Plugin.instance.swipeback_scroll_hook:
                            Plugin.instance.unhook_method(Plugin.instance.swipeback_scroll_hook)
                        
                        def on_touch(param):
                            [e] = param.args
                            action = e.getAction()
                            if action == MotionEvent.ACTION_DOWN:
                                scroll_view.requestDisallowInterceptTouchEvent(True)
                            elif action in [MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL]:
                                scroll_view.requestDisallowInterceptTouchEvent(False)
                        on_touch_method = swipe_back.getClass().getDeclaredMethod("processTouchEvent", MotionEvent)
                        Plugin.instance.swipeback_scroll_hook = Plugin.instance.hook_method(on_touch_method, self.Hook(before=on_touch))

            for child in children:
                bottom_menu_views.append((child, child.getMeasuredHeight(), "actions" if child == popup_actions_menu else "grouped" if child == popup_actions_grouped_menu else None))
 
            if popup_actions_grouped_menu and popup_actions_menu:
                menu_width = 0
                
                swipe_back = popup_actions_menu.getSwipeBack()
                if swipe_back and swipe_back.getChildCount() > 0:
                    background_view = swipe_back.getChildAt(0)
                    if background_view:
                        background_view.measure(w_spec, h_spec)
                        menu_width = background_view.getMeasuredWidth()
                
                if menu_width <= 0:
                    popup_actions_menu.measure(w_spec, h_spec)
                    menu_width = popup_actions_menu.getMeasuredWidth()

                menu_width = min(max(menu_width, AndroidUtilities.dp(200)), display_width - AndroidUtilities.dp(32))
                
                menu_lp = popup_actions_menu.getLayoutParams()
                if menu_lp:
                    menu_lp.width = menu_width
                    popup_actions_menu.setLayoutParams(menu_lp)
                
                grouped_lp = popup_actions_grouped_menu.getLayoutParams()
                if grouped_lp:
                    grouped_lp.width = menu_width
                    grouped_lp.topMargin = AndroidUtilities.dp(-8)
                    popup_actions_grouped_menu.setLayoutParams(grouped_lp)
                
                exact_w_spec = View.MeasureSpec.makeMeasureSpec(menu_width, View.MeasureSpec.EXACTLY)
                popup_actions_grouped_menu.measure(exact_w_spec, h_spec)
 
            bottom_menu_height = sum([x[1] for x in bottom_menu_views])
            scroll_view.addView(inner_container)
            new_content.addView(scroll_view)

            if cell:
                original_msg_x, original_msg_y = AndroidUtils.get_location_on_screen(current_message_cell)
            else:
                original_msg_y = self.original_y + reactions_height
                original_msg_x = 0
                inner_container.setPadding(self.original_x,0,0,0)
            
            top_limit = AndroidUtilities.statusBarHeight + AndroidUtilities.dp(24)
            bottom_limit = AndroidUtilities.navigationBarHeight + AndroidUtilities.dp(12)
            
            padding_top = original_msg_y - reactions_height
            
            menu_height = reactions_height + bottom_menu_height + message_height
            
            if display_height - padding_top < menu_height:
                padding_top = display_height - menu_height

            if padding_top < top_limit:
                padding_top = top_limit
            elif padding_top + menu_height > display_height - bottom_limit:
                padding_top = display_height - bottom_limit - menu_height

            bar = False
            need_scroll = padding_top + menu_height - reactions_height > display_height
            scroll_bottom = False
            if need_scroll:
                if Plugin.scroll_from_bottom():
                    scroll_view.post(RunnableFactory(lambda: scroll_view.fullScroll(View.FOCUS_DOWN)))
                    scroll_bottom = True
                    
                if reactions_view is not None and Plugin.sticky_reactions_bar() and cell and is_out is not None:
                    reactions_bar = FrameLayout(ctx())
                    reactions_bar.addView(reactions_view)
                    reactions_view.setLayoutParams(LayoutHelper.createFrame(WRAP_CONTENT, WRAP_CONTENT, gravity))
                    new_content.addView(reactions_bar, lp)
                    reactions_bar.setTranslationY(padding_top)
                    bar = True
            
            if reactions_view is not None and not bar:
                inner_container.addView(reactions_view, 0)
            
            real_reactions_height = reactions_height if bar else 0
            if padding_top + menu_height - real_reactions_height > display_height - bottom_limit:  
                scroll_view.setPadding(0, 0, 0, bottom_limit)
              
            spacer = View(ctx())
            spacer.setLayoutParams(LinearLayout.LayoutParams(MATCH_PARENT, int(padding_top + real_reactions_height)))
            spacer.setOnClickListener(dismiss)
            inner_container.addView(spacer, 0)
            
            message_y = padding_top + reactions_height
            
            this.setContentView(new_content)
            
            def animate(out):
                if not out and scroll_bottom:
                    scroll_y = menu_height + real_reactions_height - display_height
                elif out:
                    scroll_y = scroll_view.getScrollY()
                else:
                    scroll_y = 0
                    
                nonlocal original_msg_y
                if cell and out:
                    _, original_msg_y = AndroidUtils.get_location_on_screen(current_message_cell)
                    
                return self.animate(
                    out, 
                    this, 
                    (original_msg_y - message_y + scroll_y) if cell else None, 
                    bottom_menu_views, 
                    current_chat_activity, 
                    current_message_cell if cell else None, 
                    reactions_view, 
                    cell,
                    inner_container)
            
            if gravity != None and is_message and (popup_actions_menu != None or reactions_view != None or popup_actions_grouped_menu != None):
                avatar_width = AndroidUtilities.dp(48) if current_message_cell.needDrawAvatar() else 0
                pad = int(SharedConfig.bubbleRadius / 2) if gravity == Gravity.LEFT else AndroidUtilities.dp(8)
                mar = original_msg_x + avatar_width + pad if gravity == Gravity.LEFT else original_msg_x + current_message_cell.getWidth() - current_message_cell.getBoundsRight()
                
                menu_translation = 0
                if popup_actions_menu:
                    if gravity == Gravity.LEFT:
                        width = popup_actions_menu.getMeasuredWidth()
                        if mar + width + pad > display_width or mar < pad:
                            menu_translation = pad
                        else:
                            menu_translation = mar
                    elif gravity == Gravity.RIGHT:
                        menu_translation = min(display_width - pad, mar)
                
                for view in[popup_actions_menu, reactions_view, popup_actions_grouped_menu]:
                    if view is None:
                        continue
                    
                    translation = 0
                    if view == reactions_view:
                        if gravity == Gravity.LEFT:
                            width = view.getMeasuredWidth()
                            if mar + width + pad > display_width or mar < pad:
                                translation = pad
                            else:
                                translation = mar
                        elif gravity == Gravity.RIGHT:
                            translation = min(display_width - pad, mar)
                            
                        reactions_view.setMirrorX(is_out)
                        
                        message_left = original_msg_x + current_message_cell.getBackgroundDrawableLeft()
                        message_right = original_msg_x + current_message_cell.getBackgroundDrawableRight()
                        
                        message_tail = AndroidUtilities.dp(SharedConfig.bubbleRadius)
                        bubble_margin = (view.radius + AndroidUtilities.dp(8)) / 2
                        min_x = bubble_margin
                        max_x = view.getMeasuredWidth() - bubble_margin
                        
                        if is_out:
                            x = message_left + message_tail
                            layout_left = display_width - view.getMeasuredWidth()
                            reactoins_left = layout_left + translation
                            bubble_offset = x - reactoins_left - reactions_view.bigCircleOffset
                            bubble_offset = max(min_x - reactions_view.bigCircleOffset, min(bubble_offset, max_x - reactions_view.bigCircleOffset))
                        else:
                            x = message_right - message_tail
                            reactoins_left = translation
                            bubble_offset = x - reactoins_left - view.getMeasuredWidth() + reactions_view.bigCircleOffset
                            bubble_offset = max(min_x - view.getMeasuredWidth() + reactions_view.bigCircleOffset, min(bubble_offset, max_x - view.getMeasuredWidth() + reactions_view.bigCircleOffset))
                        
                        reactions_view.setBubbleOffset(bubble_offset)
                    else:
                        translation = menu_translation
                            
                    if translation != 0:
                        view.setTranslationX(translation)
             
            animate(False)
                  
            def on_dimiss(param):
                if this == param.thisObject:           
                    if param.args[0]: 
                        self._pop_globals()
                        self.out_animation = animation = animate(True)
                        if animation is not None:
                            param.setResult(None)
                            new_content.setClickable(False)
                            scroll_view.setClickable(False)
                            inner_container.setClickable(False)
                            animation.addListener(AnimatorListener(lambda *a: this.dismiss(False)))
                    else:
                        for hook in [Plugin.instance.draw_hook, Plugin.instance.dismiss_hook, Plugin.instance.swipeback_scroll_hook]:
                            if hook is None:
                                continue
                            Plugin.instance.unhook_method(hook)
                            
                        Plugin.instance.draw_hook = None
                        Plugin.instance.dismiss_hook = None
                        Plugin.instance.swipeback_scroll_hook = None

            def has_animated_emojis(cell):
                return cell.animatedEmojiStack and not cell.animatedEmojiStack.holders.isEmpty()
            
            bot_buttons = get_private_field(current_message_cell, "botButtons")
            bot_buttons = bot_buttons if bot_buttons and not bot_buttons.isEmpty() else None
            
            def on_draw(param):
                 if param.thisObject.getTag() == __id__:
                    canvas = param.args[0]

                    if has_animated_emojis(param.thisObject):
                        param.thisObject.drawAnimatedEmojis(canvas, JFloat(1))
                    
                    if bot_buttons:
                        call_private_method(param.thisObject, "drawBotButtons", canvas, bot_buttons, JInt(255))

            if Plugin.instance:
                if Plugin.instance.dismiss_hook is None:
                    Plugin.instance.dismiss_hook = Plugin.instance.hook_method(
                        ActionBarPopupWindow.getClass().getDeclaredMethod("dismiss", jboolean), 
                        self.Hook(before=on_dimiss))

                if Plugin.instance.draw_hook is None and is_message and (has_animated_emojis(current_message_cell) or bot_buttons is not None):
                    Plugin.instance.draw_hook = Plugin.instance.hook_method(
                        ChatMessageCell.getClass().getDeclaredMethod("drawInternal", Canvas),
                        self.Hook(after=on_draw))
            
        except Exception as e:
            log(e)
    
    class Hook(MethodHook):
        def __init__(self, *, before = None, after = None) -> None:
            super().__init__()
            self.before = before
            self.after = after
            
        def before_hooked_method(self, param):
            try:     
                if self.before:
                    self.before(param)
            except Exception as e:
                log(e)

        def after_hooked_method(self, param):
            try:
                if self.after:
                    self.after(param)
            except Exception as e:
                log(e)
    
    def animate(self, out: bool = False, popup: ActionBarPopupWindow | None = None, message_translation: int | None = None, bottom_menu_views: list[tuple[View, int, str | None]] | None = None, current_chat_activity: ChatActivity | None = None, current_message_cell: ChatActionCell | ChatMessageCell | None = None, reactions_view: View | None = None, new_cell: ChatActionCell | ChatMessageCell | None = None, inner_container = None):
        try:
            radius = int(Plugin.get_radius() / 3)
            radius_dp = AndroidUtilities.dp(radius)
            speed = Plugin.get_animation_speed()
            duration = int(250 / speed) if speed > 0 else 0
            interploator = AccelerateInterpolator() if out else DecelerateInterpolator()
            alt = Plugin.use_alt_blur()
            
            if message_translation is not None and message_translation == 0:
                message_translation = None
            
            def alt_blur(enable):
                drawable = popup.getBackground()
                if enable and drawable is None and current_chat_activity is not None:
                    bitmap = AndroidUtilities.makeBlurBitmap(content(current_chat_activity), 24, int(radius / 4))
                    drawable = BitmapDrawable(bitmap).mutate()
                    drawable.setColorFilter(Color.parseColor("#35000000"), PorterDuff.Mode.DARKEN)
                    popup.setBackgroundDrawable(drawable)
                    set_cell_visibility(not out)
                    if speed != 0 and new_cell:
                        new_cell.post(RunnableFactory(lambda: set_cell_visibility(out)))
                elif not enable and drawable is not None:
                    run_on_ui_thread(lambda: popup.setBackgroundDrawable(None), duration)
                
                if speed != 0:
                    animations.append(ObjectAnimator.ofInt(drawable, "alpha", 0, 255))
               
            def set_cell_visibility(visible):
                if not new_cell or not message_translation or not isinstance(current_message_cell, ChatMessageCell):
                    return
                
                if visible:
                    current_message_cell.updateTranslation()
                else:
                    def do():
                        current_message_cell.setTranslationX(current_message_cell.getTranslationX() + display_width * 2)
                    
                    if alt: 
                        do()
                    else:        
                        new_cell.post(RunnableFactory(do))
               
            if speed == 0:  
                set_cell_visibility(out)       
                if not alt:
                    apply_blur(content(current_chat_activity), radius_dp if not out else 0)
                else:
                    alt_blur(not out)
            else:
                animations = []         
                
                if not out:
                    set_cell_visibility(False)
                
                if current_chat_activity is not None:
                    if not alt:
                        animator = ValueAnimator.ofFloat(0.0, radius_dp)
                        animator.addUpdateListener(AnimatorUpdateListener(lambda animation, c = current_chat_activity: apply_blur(content(c), animation.getAnimatedValue())))
                        animations.append(animator)
                    else:
                        alt_blur(not out)
                
                if message_translation is not None and popup is not None:
                    c = inner_container or popup.getContentView()
                    animator = ObjectAnimator.ofFloat(c, "translationY", message_translation, 0)
                    animations.append(animator)
                
                def fade_anim(view, scale = 0.3):
                    animators = [
                        ObjectAnimator.ofFloat(view, "scaleX", scale, 1),
                        ObjectAnimator.ofFloat(view, "scaleY", scale, 1),
                        ObjectAnimator.ofFloat(view, "alpha", 0 if out else 0.5, 1)
                    ]
                    animations.extend(animators)
                
                if bottom_menu_views is not None:
                    pivot_y = 0
                    for view, height, tag in bottom_menu_views:
                        view.setPivotY(pivot_y / 2)
                        pivot_y -= height
                        view.setPivotX(view.getMeasuredWidth() / 2)
                        fade_anim(view, 0 if tag == "grouped" else 0.3)    

                if reactions_view is not None:
                    reactions_view.setPivotY(reactions_view.getMeasuredHeight())
                    reactions_view.setPivotX(reactions_view.getMeasuredWidth() / 2)
                    fade_anim(reactions_view)
                
                if len(animations) > 0:
                    set = AnimatorSet()
                    set.playTogether(*animations)
                    set.setDuration(duration)
                    set.setInterpolator(interploator)
                    if not out:
                        set.start()
                    else:
                        set.reverse()
                    
                    if new_cell is not None and message_translation is not None and isinstance(current_message_cell, ChatMessageCell):
                        if out:
                            run_on_ui_thread(lambda: set_cell_visibility(True), max(0, duration - self.cell_stopwatch.pop_int() - 50))
                            def on_end():
                                recycler = get_private_field(current_chat_activity, "chatListView")
                                position = recycler.getChildAdapterPosition(current_message_cell)
                                if position >= 0:
                                    get_private_field(current_chat_activity, "chatAdapter").notifyItemChanged(position)
                            set.addListener(AnimatorListener(lambda *_: on_end()))
                        else:
                            self.cell_stopwatch.start()                 
                            new_cell.post(RunnableFactory(lambda: self.cell_stopwatch.stop()))
                    else:
                        self.cell_stopwatch.reset()
                    return set
            return None
        except Exception as e:
            log(e)
            return None
    
    @staticmethod
    def _copy_message_cell(cell: ChatMessageCell | ChatActionCell | None):
        if isinstance(cell, ChatMessageCell):
            new_cell = ChatMessageCell(
                ctx(),
                cell.currentAccount,
                False,
                get_private_field(cell, "sharedResources"),
                get_private_field(cell, "resourcesProvider"))
            cell.copyParamsTo(new_cell)
            
            mobj = cell.getMessageObject()
            
            # thx @mishabotov
            if mobj.type == MessageObject.TYPE_POLL:
                poll_buttons = cell.getPollButtons()
                if poll_buttons and poll_buttons.size() > 0:
                    new_cell.firstVisiblePollButton = 0
                    new_cell.lastVisiblePollButton = poll_buttons.size() - 1
            
            new_cell.setMessageObject(
                mobj, 
                cell.getCurrentMessagesGroup(),
                cell.pinnedBottom,
                cell.pinnedTop,
                cell.firstInChat)
            
            new_cell.setDelegate(cell.getDelegate())
        elif isinstance(cell, ChatActionCell):
            new_cell = ChatActionCell(
                ctx()
            )
            
            new_cell.setMessageObject(cell.getMessageObject(), True)
        else:
            new_cell = None
        
        if new_cell:
            new_cell.setTag(__id__)
            
        return new_cell

class CreateMenuHook(MethodHook):
    def before_hooked_method(self, param):
        global current_chat_activity, current_message_cell
        current_chat_activity = param.thisObject
        current_message_cell = param.args[0]
        touch_stopwatch.start()

class AnimatorUpdateListener(dynamic_proxy(ValueAnimator.AnimatorUpdateListener)):
    def __init__(self, fn: Callable[[ValueAnimator], None]):
        super().__init__()
        self.fn = fn
        
    def onAnimationUpdate(self, animation):
        self.fn(animation)

class OnPopupDismiss(dynamic_proxy(PopupWindow.OnDismissListener)):
    def __init__(self, fn: Callable[[], None]):
        super().__init__()
        self.fn = fn
    
    def onDismiss(self):
        self.fn()

class RunnableFactory(dynamic_proxy(Runnable)):
    def __init__(self, fn: Callable):
        super().__init__()
        self.fn = fn
    
    def run(self):
        try:
            self.fn()
        except Exception as e:
            log(e)

class AnimatorListener(dynamic_proxy(Animator.AnimatorListener)):
    def __init__(self, on_end: Callable):
        super().__init__()
        self.on_end = on_end
        
    def onAnimationEnd(self, *a):
        self.on_end(*a)

class OnTouchListener(dynamic_proxy(View.OnTouchListener)):
    def __init__(self, on_touch: Callable):
        super().__init__()
        self.on_touch = on_touch
    
    def onTouch(self, view, event):
        result = self.on_touch(view, event)
        if not isinstance(result, bool):
            return True
        return result

class AndroidUtils:
    @staticmethod
    def get_location_on_screen(view) -> Tuple[int, int]:
        from java import jarray, jint
        array = jarray(jint)(2)
        view.getLocationInWindow(array)
        return array[0], array[1] 